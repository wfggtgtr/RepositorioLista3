﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double valor = 0;

            do
            {

                Console.Write("Digite o valor: ");
                valor = double.Parse(Console.ReadLine());

            }
            while (valor < 0);

        }    
    }
}

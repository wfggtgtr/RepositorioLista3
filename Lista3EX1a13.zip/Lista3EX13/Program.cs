﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista2EX13
{
    internal class Program
    {
        static void Main(string[] args)
        {
            char resp;
            
            do
            {
                double valor = 0;
                double cont = 1;
                double fat = 1;
                Console.WriteLine("\nDigite um Valor:");
                valor = double.Parse(Console.ReadLine());
                while (valor < 0)
                {
                    Console.WriteLine("Erro!");
                    Console.WriteLine("Informe esse Valor Novamente: ");
                    valor = double.Parse(Console.ReadLine());
                }
                do
                {
                    fat = fat * cont;
                    cont++;

                }
                while (cont <= valor);
                Console.WriteLine("{0}! = {1}", valor, fat);
                Console.WriteLine("");
                do
                {
                    Console.WriteLine("Executar novamente (s) para sim, (n) para não?");
                    resp = char.Parse(Console.ReadLine());
                } while (resp != 's' && resp != 'n');
            } while (resp != 'n');
        }
    }
}

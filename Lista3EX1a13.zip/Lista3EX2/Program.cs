﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista3EX2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double v1 = 0;
            double v2 = 0;

            Console.Write("Digite o primeiro valor: ");
            v1 = double.Parse(Console.ReadLine());

            do
            {
                Console.Write("Digite o segundo valor: ");
                v2 = double.Parse(Console.ReadLine());

            } while (v2 <= v1);
        }
    }
}

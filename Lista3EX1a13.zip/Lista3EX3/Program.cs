﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista3EX3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            char sexo;

            do
            {
                Console.WriteLine("Digite o sexo: para feminino (F) e para masculino (M):");
                sexo = char.Parse(Console.ReadLine());

            } while (sexo != 'M' && sexo != 'F');
        }
    }
}

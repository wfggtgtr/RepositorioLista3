﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista3EX4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double v1 = 0;
            int cont = 0;

            do
            {
                cont++;
                v1 = 5 * cont;
                Console.WriteLine(" 5 x {0} = {1}", cont, v1);

            }while (cont < 10);
        }
    }
}

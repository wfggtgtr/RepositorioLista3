﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista3EX5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double v1 = 0;
            double resultado = 0;
            int cont = 0;

            do
            {
                Console.WriteLine(" Digite um valor : ");
                v1 = double.Parse(Console.ReadLine());

            } 
            while (v1 < 0);

            do
            {
                cont++;
                resultado = v1 * cont;
                Console.WriteLine(" {0} x {1} = {2}", cont, v1, resultado);

            }
            while (cont < 10);
        }
    }
}

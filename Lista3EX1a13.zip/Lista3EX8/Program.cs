﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista3EX8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double cont = 0;
            double resultado = 0;

            do
            {
                cont++;
                resultado = resultado + cont;

            } while (cont < 100);
            
            Console.WriteLine("A soma dos numeros positivos no intervalo de 1 a 100: {0}", resultado);
        }
    }
}
